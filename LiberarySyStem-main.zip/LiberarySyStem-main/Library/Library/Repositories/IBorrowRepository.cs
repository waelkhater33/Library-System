﻿using Library.Models;

namespace Library.Repositories
{
    public interface IBorrowRepository
    {
        //List<ApplicationUser> getAllUsers();
    }
}
