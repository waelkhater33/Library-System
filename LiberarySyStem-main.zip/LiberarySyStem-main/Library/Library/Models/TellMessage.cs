﻿namespace Library.Models
{
    public class TellMessage
    {
        public string Message { get; set; }
        public string Controller { get; set; }
        public string Action { get; set; }
        public string ButtonLabel { get; set; }
        public string Header { get; set; }

    }
}
