﻿namespace Library.ViewModel
{
    public class WishListCountVM
    {
        public int Count { get; set; }
    }
}
