﻿namespace Library.ViewModel.Account
{
    internal class DateTypeAttribute : Attribute
    {
    }
}