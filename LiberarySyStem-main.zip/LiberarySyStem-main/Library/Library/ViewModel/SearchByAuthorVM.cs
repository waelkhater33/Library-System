﻿namespace Library.ViewModel
{
    public class SearchByAuthorVM
    {
        public int AuthorId { get; set; }
        public string Name { get; set; }
    }
}
